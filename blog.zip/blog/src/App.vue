<template>
  <router-view></router-view>
</template>

<script>

</script>

<style>

body{
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
}
</style>